create procedure ss(IN test tinyint(1))
  BEGIN
	#Routine body goes here...
	DECLARE i int;
	set i = 1;
	while i < 13 do
	insert into commidityinfo(id_commidity,commidity_name,commidity_price,exchange_num,assist_price,id_exchange_rule) select id_commidity + 1,commidity_name,commidity_price,exchange_num,assist_price,id_exchange_rule from commidityinfo where id_commidity = i;
	set i = i + 1;
	end while;
END;

